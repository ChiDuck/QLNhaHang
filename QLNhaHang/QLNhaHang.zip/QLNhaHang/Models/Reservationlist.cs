﻿namespace QLNhaHang.Models
{
    public partial class Reservationlist
    {
        public int IdReservationlist { get; set; }
        public int Quantity { get; set; }
        public int Total { get; set; }
    }
}
