﻿using Microsoft.AspNetCore.Mvc;

namespace QLNhaHang.Controllers.View
{
	public class ShiporderController : Controller
	{
		public IActionResult Index()
		{
			return View();
		}
	}
}
