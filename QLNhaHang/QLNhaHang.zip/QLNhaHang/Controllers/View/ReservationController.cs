﻿using Microsoft.AspNetCore.Mvc;

namespace QLNhaHang.Controllers.View
{
    public class ReservationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
